insert into passport( id, number)
values(50001, 'E123456');


insert into passport(id, number)
values(50002, 'E25468');


insert into student(id, name, passport_id)
values(20001, 'Varun', 50001);


insert into student(id, name, passport_id)
values(20002, 'Shubham', 50002);




